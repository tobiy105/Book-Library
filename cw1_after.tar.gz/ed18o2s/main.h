int main();
static void login_menu();
void menu(unsigned int type);